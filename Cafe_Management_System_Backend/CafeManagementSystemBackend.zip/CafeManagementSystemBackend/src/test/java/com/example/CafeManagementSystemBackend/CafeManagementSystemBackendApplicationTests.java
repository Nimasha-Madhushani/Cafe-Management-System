package com.example.CafeManagementSystemBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CafeManagementSystemBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
