package com.example.CafeManagementSystemBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CafeManagementSystemBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(CafeManagementSystemBackendApplication.class, args);
	}

}
